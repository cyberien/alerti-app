<?php
/**
 * alerti module for Craft CMS 3.x
 *
 * alerti
 *
 * @link      https://github.com/aminembarki
 * @copyright Copyright (c) 2021 Amine Mbarki
 */

/**
 * @author    Amine Mbarki
 * @package   AlertiModule
 * @since     1.0.0
 */
return [
    'alerti plugin loaded' => 'alerti plugin loaded',
];
