<?php
/**
 * kanban module for Craft CMS 3.x
 *
 * kanban 
 *
 * @link      https://github.com/aminembarki
 * @copyright Copyright (c) 2021 Amine Mbarki
 */

/**
 * @author    Amine Mbarki
 * @package   KanbanModule
 * @since     1.0.0
 */
return [
    'kanban plugin loaded' => 'kanban plugin loaded',
];
